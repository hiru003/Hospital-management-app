# FairShift × NilaCare Medical Centre — Hackathon Prototype

A responsive, single-page prototype for fairer and safer work, aligned with UN SDG 8 (Decent Work and Economic Growth).

## Features
- Worker portal and admin dashboard
- Shift check-in/check-out and live elapsed-hour estimate
- **No break-time deduction:** shift hours are calculated as the full elapsed time between check-in and check-out; the prototype does not subtract break duration
- Transparent pay estimate with configurable hourly rate and overtime multiplier
- Workplace hazard reports, anonymous display option, and admin status updates
- Hospital and college support-staff sector examples
- Responsive layout for desktop and mobile
- Demo data stored in browser `localStorage`

## Run
Open `index.html` directly in a browser, or serve the folder with a local development server. No build step is required.

## Important limitations
This is a hackathon demo, not a production payroll or workforce system. It has no real authentication, backend, verified identity, geolocation, or access controls. Do not enter real patient or sensitive employee information. Demo data is stored locally in the browser. Pay rules and applicable employment requirements should be validated before any real-world use.
